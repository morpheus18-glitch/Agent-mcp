import SandboxEnvironment from "@/components/sandbox-environment"

export default function SandboxPage() {
  return (
    <div className="container mx-auto py-8">
      <SandboxEnvironment />
    </div>
  )
}
