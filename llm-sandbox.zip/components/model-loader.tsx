"use client"

// This component is a placeholder that doesn't load any external resources
export default function ModelLoader() {
  return null
}
