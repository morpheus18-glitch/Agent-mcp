import json
from channels.generic.websocket import AsyncWebsocketConsumer
from channels.db import database_sync_to_async
from django.contrib.auth import get_user_model
from .models import Conversation, UserAccess

User = get_user_model()

class ConversationConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        self.conversation_id = self.scope['url_route']['kwargs']['conversation_id']
        self.conversation_group_name = f'conversation_{self.conversation_id}'
        
        # Get the user from the scope
        user = self.scope['user']
        
        # Check if the user has access to the conversation
        if not await self.has_conversation_access(user, self.conversation_id):
            await self.close()
            return
        
        # Join the conversation group
        await self.channel_layer.group_add(
            self.conversation_group_name,
            self.channel_name
        )
        
        await self.accept()
    
    async def disconnect(self, close_code):
        # Leave the conversation group
        await self.channel_layer.group_discard(
            self.conversation_group_name,
            self.channel_name
        )
    
    async def receive(self, text_data):
        # We don't expect to receive messages from clients in this consumer
        pass
    
    @database_sync_to_async
    def has_conversation_access(self, user, conversation_id):
        # Anonymous users don't have access
        if not user.is_authenticated:
            return False
        
        try:
            conversation = Conversation.objects.get(id=conversation_id)
            
            # Admin users have access to all conversations
            if user.role == 'admin':
                return True
            
            # Creator has access
            if conversation.created_by == user:
                return True
            
            # Public conversations are accessible to all authenticated users
            if conversation.is_public:
                return True
            
            # Check for explicit access
            return UserAccess.objects.filter(
                user=user,
                conversation_id=conversation_id
            ).exists()
        except Conversation.DoesNotExist:
            return False
    
    async def new_message(self, event):
        # Send message to WebSocket
        await self.send(text_data=json.dumps({
            'type': 'new_message',
            'message': event['message']
        }))
    
    async def conversation_updated(self, event):
        # Send conversation update to WebSocket
        await self.send(text_data=json.dumps(event))
    
    @classmethod
    def new_message(cls, conversation_id, message):
        from channels.layers import get_channel_layer
        from asgiref.sync import async_to_sync
        
        channel_layer = get_channel_layer()
        async_to_sync(channel_layer.group_send)(
            f'conversation_{conversation_id}',
            {
                'type': 'new_message',
                'message': message
            }
        )
    
    @classmethod
    def conversation_updated(cls, conversation_id, event):
        from channels.layers import get_channel_layer
        from asgiref.sync import async_to_sync
        
        channel_layer = get_channel_layer()
        async_to_sync(channel_layer.group_send)(
            f'conversation_{conversation_id}',
            {
                'type': 'conversation_updated',
                **event
            }
        )
